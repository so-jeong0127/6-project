# 5조
# 작성일 : 2019. 12. 13
# 제출일 : 2019. 12. 13


library(wordcloud)
library(wordcloud2)
library(KoNLP)
library(RColorBrewer)

library(dplyr)
library(ggplot2)

setwd('D:/workR')
text4 <- readLines('text.txt', encoding = 'UTF-8')
text4

noun4 <- sapply(text4, extractNoun, USE.NAMES = F)  
noun4

noun4 <- unlist(noun4)            #list <- vector로 변환

noun4 <- noun4[nchar(noun4)>=2]   

coun4<- table(noun4)

sort.noun4 <- sort(coun4, decreasing = T)[1:10]
sort.noun4
sort.noun4 <- sort.noun1[-3]            #3번째가 공백임.

wordcloud2(coun4,
           color = 'random-light',size = 1)


#외국인 투자현황(중국자본 유입)
setwd("c:/workR/homeworkData")
invest<- read.xlsx(file="산업통상자원부_지자체별외국인투자현황.xlsx",sheetIndex=1,encoding="UTF-8", header=T)
invest
str(invest)
View(invest)
in1 <- invest[50:56,]                #2011년 전의 데이터 제거, 2018년 데이터 제거(반기 수치임)
in1
View(in1)
in1_j <- in1$제주_신고금액+in1$제주_도착금액      #각 년도에 금액을 모두 더해서 사용함
in1_j

in1_b <- in1$부산_신고금액+in1$부산_도착금액
in1_b

in1_d <- in1$대구_신고금액+in1$대구_도착금액
in1_d

in1_I <- in1$인천_신고금액+in1$인천_도착금액
in1_I

plot(year, in1_j, main='지자체별외국인투자현황(단위:백만달러)',
     type='b', lty=1, lwd=2,
     xlab='연도', ylab="금액",col="red")  #제주
lines(year, in1_b, type = "b", lty=1, lwd=2, col="black") #부산
lines(year, in1_d, type = "b", lty=1, lwd=2, col="navy")  #대구
lines(year, in1_I, type = "b", lty=1, lwd=2, col="violet") #인천


#-----------------------------------------------------------------------------------------------

setwd('D:/5_project/가설1')
trans <- read.csv('transfer.csv')
trans
population <- read.csv('population.csv')
population

str(population)

#제주 전체인구와 유입인구의 가중치
per<- trans$count/population$population
per
#필요시 곱
per1<- per*100
year <- 2015:2018
year
weight <- data.frame(year,per)
weight

#신규 산업체수*가중치
employ <- read.csv('employee.csv')
employ
ex<- employ$X2016*0.06293826 #2016년 산업별 신규 산업체 수 * 가중치(이주민 수)
re<- employ$X2017*0.06354144 #2017년 산업별 신규 산업체 수 * 가중치(이주민 수)
ex; re
industry <- c("전체 산업","농업/임업/어업","광업","제조업",
              "전기,가스,증기 및 공기조절 공급업",
              "수도,하수 및 폐기물 처리, 원료 재생업",
              "건설업","도매 및 소매업","운수 및 창고업",
              "숙박 및 음식점업","정보통신업","금융 및 보험업",
              "부동산업","전문, 과학 및 기술 서비스업",
              "사업시설 관리/사업 지원 및 임대 서비스업",
              "공공행정, 국방 및 사회보장 행정","
              교육 서비스업","보건업 및 사회복지 서비스업",
              "예술/스포츠 및 여가관련 서비스업",
              "협회 및 단체/수리 및 기타 개인 서비스업")
weight2<- data.frame(industry, ex,re)
weight2
weight2 <- weight2[-1,]
weight2 <- subset( weight2, weight2$ex >= 100 & weight2$re >= 100)

# par(mfrow = c(1,2))
# hist( weight2$ex, xlab = "2016년 가중치" )
# hist( weight2$re, xlab = "2017년 가중치" )
# par(mfrow = c(1,1))

class(weight2)


setwd('D:/5_project/가설1')
weight2
write.csv( weight2, "weight.csv", row.names = F, quote = F)







