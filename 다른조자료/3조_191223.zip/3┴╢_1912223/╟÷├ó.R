setwd("c:/이현창")

library(readxl)

#비정규자 
data <- read_excel("시도_성_활동상태_취업희망여부별_비경제활동인구_20191212194347.xlsx")
data
data2 <- read_excel("고용보험_신규취득자수_시도__20191212202201.xlsx")
data2
data2 <- data.frame(data2)

str(data2)
data2
plot(x = data$...1, y = data$비경제활동인구, type  ='o' ,col ='red',
     xlab = '년도' , ylab = '취득 희망자 수',ylim = c(0,160000))
lines(data2[1:5,] , type = 'o', col='blue')
data2

data$비경제활동인구/data2$값

data3 <- read_excel("행정구역_시도__성별_취업자_201912121609091.xlsx")
data3
a <- (data3$`2014`/data3$`2013`-1) *100
a_2014 <- data.frame(data3$`행정구역별(1)` , a)

b <- (data3$`2015`/data3$`2014` -1)*100
a_2015 <- data.frame(data3$`행정구역별(1)`, b)

c <- (data3$`2016`/data3$`2015`-1) *100
a_2015 <- data.frame(data3$`행정구역별(1)`, c)
a_2015

d <- (data3$`2017`/data3$`2016`-1) *100
a_2015 <- data.frame(data3$`행정구역별(1)`, d)

f <- cbind(a,b,c,d)
f

#_--------------------------------------
#실업률

fm <- read_excel("행정구역_시도__성별_경제활동인구_실업률.xlsx")
fm1 <- data.frame(fm)[19,-2]
fm1 <- unlist(fm1[,-1])
fm1 <- as.numeric(fm1)
fm2 <- colnames(fm)
fm2 <- fm2[c(-1,-2)]
fm2 <- as.numeric(fm2)
fm3 <- cbind(fm2,fm1)
fm3

#제주도 실업률 

plot(fm3 , type = 'o' , col = "red" , xlab = "년도"
     , ylab = "비율")

#고용률

fm_2 <- read_excel("행정구역_시도__성별_경제활동인구_20191213101103.xlsx")
fm1_2 <- data.frame(fm_2)[19,-2]
fm1_2 <- unlist(fm1_2[,-1])
fm1_2 <- as.numeric(fm1_2)
fm2_2 <- colnames(fm_2)
fm2_2 <- fm2_2[c(-1,-2)]
fm2_2 <- as.numeric(fm2_2)
fm3_2 <- cbind(fm2_2,fm1_2)
fm3_2
fm3

#제주도 고용률
plot(fm3_2, type="o", col="blue" , xlab = "년도",
     ylab = "고용률")

#분기별 제주도 고용률

fm_2 <- read_excel("행정구역_시도__성별_경제활동인구_분기.xlsx")
fm_2 <- fm_2[-1,c(-1,-2)]
fm_2_1 <- unlist(fm_2)
fm_2_1 <- as.numeric(fm_2_1)
View(fm_2)
name1 <- colnames(fm_2)

str(fm_2_2)
fm_2_2 <- data.frame(fm_2_2)
vifm_2_2
str(fm_2_2)
plot(fm_2_1, type = "o" )

#전국적 도 별로 2018 기준 고용률 비교
max(fm_2_1)
fm3 <- read_excel("행정구역_시도__성별_경제활동인구_1.xlsx")
fm3 <- data.frame(fm3)
fm3 <- fm3[c(-1,-2),-2]
fm3_1 <- as.numeric(fm3$X2018)
names(fm3_1) <- fm3$시도별
fm4_1 <- sort(fm3_1)
fm4_1
fm3_1
barplot(fm4_1, ylim = c(0,100),
        xlab = "도별",
        ylab = "고용률")

#빈 일자리
fm4 <- read_excel("시도_단위_고용통계_1.xlsx")
fm4
fm4 <- data.frame(fm4[-1,-2])
fm4_1 <- unlist(fm4$X2018)
names(fm4_1) <- fm4$지역별
fm4_1 <- sort(fm4_1)
barplot(fm4_1, names = name, ylim = c(0,2),
        xlab = "도별",
        ylab = "빈 일자리")
