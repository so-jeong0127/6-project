#자영업자 비율
employ <- read.csv("행정구역_시도__종사상지위별_취업자.csv",
                    stringsAsFactors=FALSE, fileEncoding = "CP949", encoding="UTF-8" )

head(employ)
str(employ)
employ <- employ[,c(1,2,8)]
employ

city <- unique(employ[,1])
city_names <- c("서울","부산","대구","인천","광주","대전",
                "울산","세종","경기","강원","충북","충남",
                "전북", "전남","겅북","경남","제주")

status <- unique(employ[,2])
status

sleep

ttl <- employ[employ[,2] == status[1],]
owner <- employ[employ[,2] == status[3],]
owner_hire <- employ[employ[,2] == status[4],]
owner_alone <- employ[employ[,2] == status[5],]


o_hire_ratio <- owner_hire[,3] / owner[,3]
o_alone_ratio <- owner_alone[,3] / owner[,3]

jeju_owner <- c(o_hire_ratio[18], o_alone_ratio[18])
jeju_owner * 100

#전체 근로자 중 자영업자의 비율
owner_ratio <- owner[,3] / ttl[,3] * 100
owner_ratio <- owner_ratio[-1]
names(owner_ratio) <- city_names
owner_ratio <- sort(owner_ratio)
owner_ratio
length(owner_ratio)
sample <- c(2,4,7,10, 13,17)
#제주도가 자영업자 비율이 28.5%로 가장 높음
par(family="AppleGothic")

### 그래프 : 시도별 자영업자 비율 ### 시간 나면 예쁘게 다시 ...
barplot(owner_ratio[sample], xlab="시도", ylab="비율(%)", main="자영업자 비율")


#자영업자 중 1인 영세 사업자의 비율 : 75.9% (평균인 75.1%보다 높음)
p_owner_ratio <- owner_alone[,3] / owner[,3] * 100
p_owner_ratio <- p_owner_ratio[-1]
names(p_owner_ratio) <- city_names
p_owner_ratio <-sort(p_owner_ratio)
p_owner_ratio

barplot(p_owner_ratio[sample], xlab="시도", ylab="비율(%)", main="영세 자영업자 비율")
boxplot(p_owner_ratio)

library(ggplot2)

subset <- employ[employ$시도별 == '제주도',][4:6, 3]
subset

#ggplot 맥 한글깨짐에
#theme_set(theme_gray(base_family='NanumGothic'))
#ggplot(subset, aes(x = 제주도, y = 종사자수, fill=자영업자분류)) + geom_bar(stat='identity')

#pie(jeju_owener) 안예뿨...
jeju_owner <- jeju_owner*100
group = c("고용원있음","고용원없음")
jeju_df <- data.frame(jeju_owner, group)
jeju_df
#자영업자 중 고용원이 없는 영세 자영업자 비중이 75.9%
bp <- ggplot( jeju_df, aes(x="", y = jeju_owner, fill = group )) +
  geom_bar(width = 1, stat = 'identity')
bp
pie <- bp + coord_polar("y", start=0)

blank_theme <- theme(axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        panel.border = element_blank(),
        panel.grid = element_blank(),
        axis.ticks = element_blank(),
        plot.title = element_text(size=12, face="bold"))

### 파이차트 : 제주 영세 자영업자 비율 75.9%
pie + blank_theme +
  theme( axis.text.x = element_blank()) 


#사업체별 수입
business <- read.csv("업태별_주소지별_사업소득_신고_현황.csv",
                   stringsAsFactors=FALSE, fileEncoding = "CP949")
business2018 <- business[-2,c(1,2,39,40,41, 45)]
business2018 <- business2018[business2018$업태별.1. == '합계',]
business2018 <- business2018[,-1]
business2018
colnames(business2018) <- c("지역","건수","매출","이익","결손건수")
str(business2018)
rownames(business2018) <- business2018[,1]
business2018 <- business2018[,-1]
names <- rownames(business2018)

library(dplyr)
business2018_2 <- mutate_all(business2018, function(x) as.numeric(as.character(x)))
str(business2018_2)

df2018 <- business2018_2 %>% mutate( 평균매출 = 매출 / 건수 ) %>%
  mutate( 평균이익 = 이익 / 건수 ) %>%
  mutate( 이익률 = 이익 / 매출 * 100 ) %>%
  mutate( 적자수비중 = 결손건수 / 건수 * 100 ) %>%
  mutate( 지역 = names )

df2018 <- df2018[-1, ]

install.packages("treemap")
library(treemap)
theme_set(theme_gray(base_family='NanumGothic'))
treemap(df2018, index="지역", vSize="평균매출", vColor="평균이익",
        type="value", bg.labels="yellow", title = "평균 매출과 영업이익",
        fontfamily.labels="AppleGothic")

df2018
#영업이익률 비교
#어떤 식으로 시각화할 지 잘 모르겠엉...
ggplot( data = df2018, aes(x = 지역, y = 이익률)) +
  geom_boxplot()

boxplot(df2018[,7], main = "영업이익률")
summary(df2018[,7])
#제주도는 평균보다 약간 높은 11.54%

sample <- c(1,3,7,8,13,17)
name <- c("서울","경기","충남","세종","경북","제주")
df2018[sample,8]
summary(df2018[,5])
boxplot(df2018[,5], main = "매출액")
#지도랑 연계해서 보여줘도 좋겠다.. 근데 지금으 ㄴ머ㅜ피곤

### 적자 사업체 비율
barplot(df2018[sample,8], xlab="시도", ylab="비율(%)", main="적자 사업체 비율")

subdf <- df2018[,8:9]
subdf


