setwd( "C:/works")
jeju_think <- read.csv( "창업에대한인식.csv", header = F )


#install.packages('ggplot2')
library(ggplot2)

#View(jeju_think)

# a: 지역별 창업에 대한 인식이 매우 개선되었다. 
a <- (jeju_think[8:12,7])
Affirmation <- as.vector(a)

Area <- c('수도권' , '충청권', '호남권' , '영남권' , '제주/강원')


df <- data.frame(Area, Affirmation)
df



ggplot( df, aes( x = Area , y = Affirmation)) +
  geom_bar( stat = "identity", width = 0.7 , fill = "steelblue")+
  labs(y = '매우 그렇다 답변 비율(%)' , x = '지역')+
  ggtitle('창업 인식 개선도 조사 ')
  


#b는 전혀 그렇지 않다.

b <- jeju_think[8:12,5]
Affirmation1 <- as.vector(b)

Area1 <- c('수도권' , '충청권', '호남권' , '영남권' , '제주/강원')

df1 <- data.frame(Area1, Affirmation1)
df1

ggplot( df1, aes( x = Area1 , y = Affirmation1)) +
  geom_bar( stat = "identity", width = 0.7 , fill = "steelblue") +
  labs(y = '전혀 그렇지않다 답변 비율(%)' , x = '지역')+
  ggtitle('창업 인식 개선도 조사 ')




# c는 제주/강원권의 인식개선에 대한 설문

x <- c('전혀 그렇지 않다', '보통이다', '매우 그렇다')
y <- c(27.8, 29.5, 42.7)

pie(y, labels = x, main = "제주/강원권의 창업인식 개선도")




