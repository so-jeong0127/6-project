setwd( "C:/works")
jeju_old <- read.csv( "제주연령연도별전입전출.csv", header = F )


#install.packages('dplyr')
#library('dplyr')

jeju_old <- jeju_old[,-1]
jeju_old <- jeju_old[-1,]
jeju_old <- jeju_old[-1,]



#2015

# a 영유아
a <- (jeju_old[1:10,2])
a <- as.vector(a)
a <- as.numeric(a)
a <- sum(a)
a

# b 10대
b <- (jeju_old[11:20,2])
b <- as.vector(b)
b <- as.numeric(b)
b <- sum(b)
b

# c 20대
c <- (jeju_old[21:30,2])
c <- as.vector(c)
c <- as.numeric(c)
c <- sum(c)
c

# d 30대 
d <- (jeju_old[31:40,2])
d <- as.vector(d)
d <- as.numeric(d)
d <- sum(d)
d

# e 40대
e <- (jeju_old[41:50,2])
e <- as.vector(e)
e <- as.numeric(e)
e <- sum(e)
e

# f 50대
f <- (jeju_old[51:60,2])
f <- as.vector(f)
f <- as.numeric(f)
f <- sum(f)
f

# g 60대
g <- (jeju_old[61:70,2])
g <- as.vector(g)
g <- as.numeric(g)
g <- sum(g)
g

#-----------------------------2015

#2016

# a1 영유아
a1 <- (jeju_old[1:10,3])
a1 <- as.vector(a1)
a1 <- as.numeric(a1)
a1 <- sum(a1)
a1

# b 10대
b1 <- (jeju_old[11:20,3])
b1 <- as.vector(b1)
b1 <- as.numeric(b1)
b1 <- sum(b1)
b1

# c 20대
c1 <- (jeju_old[21:30,3])
c1 <- as.vector(c1)
c1 <- as.numeric(c1)
c1 <- sum(c1)
c1

# d 30대 
d1 <- (jeju_old[31:40,3])
d1 <- as.vector(d1)
d1 <- as.numeric(d1)
d1 <- sum(d1)
d1

# e 40대
e1 <- (jeju_old[41:50,3])
e1 <- as.vector(e1)
e1 <- as.numeric(e1)
e1 <- sum(e1)
e1

# f 50대
f1 <- (jeju_old[51:60,3])
f1 <- as.vector(f1)
f1 <- as.numeric(f1)
f1 <- sum(f1)
f1

# g 60대
g1 <- (jeju_old[61:70,3])
g1 <- as.vector(g1)
g1 <- as.numeric(g1)
g1 <- sum(g1)
g1

#-----------------------------2016

#2017

# a 영유아
a2 <- (jeju_old[1:10,4])
a2 <- as.vector(a2)
a2 <- as.numeric(a2)
a2 <- sum(a2)
a2

# b 10대
b2 <- (jeju_old[11:20,4])
b2 <- as.vector(b2)
b2 <- as.numeric(b2)
b2 <- sum(b2)
b2

# c 20대
c2 <- (jeju_old[21:30,4])
c2 <- as.vector(c2)
c2 <- as.numeric(c2)
c2 <- sum(c2)
c2

# d 30대 
d2 <- (jeju_old[31:40,4])
d2 <- as.vector(d2)
d2 <- as.numeric(d2)
d2 <- sum(d2)
d2

# e 40대
e2 <- (jeju_old[41:50,4])
e2 <- as.vector(e2)
e2 <- as.numeric(e2)
e2 <- sum(e2)
e2

# f 50대
f2 <- (jeju_old[51:60,4])
f2 <- as.vector(f2)
f2 <- as.numeric(f2)
f2 <- sum(f2)
f2

# g 60대
g2 <- (jeju_old[61:70,4])
g2 <- as.vector(g2)
g2 <- as.numeric(g2)
g2 <- sum(g2)
g2

#--------------------------------------------------2017


#2018

# a 영유아
a3 <- (jeju_old[1:10,5])
a3 <- as.vector(a3)
a3 <- as.numeric(a3)
a3 <- sum(a3)
a3

# b 10대
b3 <- (jeju_old[11:20,5])
b3 <- as.vector(b3)
b3 <- as.numeric(b3)
b3 <- sum(b3)

b3

# c 20대
c3 <- (jeju_old[21:30,5])
c3 <- as.vector(c3)
c3 <- as.numeric(c3)
c3 <- sum(c3)
c3

# d 30대 
d3 <- (jeju_old[31:40,5])
d3 <- as.vector(d3)
d3 <- as.numeric(d3)
d3 <- sum(d3)
d3

# e 40대
e3 <- (jeju_old[41:50,5])
e3 <- as.vector(e3)
e3 <- as.numeric(e3)
e3 <- sum(e3)
e3

# f 50대
f3 <- (jeju_old[51:60,5])
f3 <- as.vector(f3)
f3 <- as.numeric(f3)
f3 <- sum(f3)
f3

# g 60대
g3 <- (jeju_old[61:70,5])
g3 <- as.vector(g3)
g3 <- as.numeric(g3)
g3 <- sum(g3)
g3



##############################################

year <- c('2015','2016','2017','2018')

kid <- c(109235,119583,116729,115677)
teen <- c(9289, 9362, 8757,8477 )
twenty <- c(14228,15902,16951,17542)
thirty <- c(21419,23042,22401,21763)
forty <- c(18360,20094,19924,19190)
fifties <- c( 12942,14497, 14430,14466)
sixty <- c(6004,7100,6969,7325)





jeju_old_new <- data.frame(year, teen ,thirty,forty,fifties,sixty )
jeju_old_new






plot(year,teen,main='제주 전입자 추이',
     
     type='b',lty=1,col='red',xlab='년도',ylab='이동자수(명)'
     
     ,ylim=c(1,25000),lwd=3)
lines(year, twenty ,type = 'b',lty=1,col='gainsboro',lwd=3)
lines(year, thirty ,type = 'b',lty=1,col='coral',lwd=3)
lines(year, forty ,type = 'b',lty=1,col='saddle brown',lwd=3)
lines(year, fifties ,type = 'b',lty=1,col='darkgreen',lwd=3)
lines(year, sixty ,type = 'b',lty=1,col='deep pink',lwd=3)

#####################################



year <- c('2015', '2016','2017','2018')

income <- c( 35647 , 74591 , 113943 , 153248)


df <- data.frame(year, income)
df

library(ggplot2)

ggplot( df, aes( x = year , y = income)) +
  geom_bar( stat = "identity", width = 0.7 , fill = "darkgreen")+
  labs(y = '전입자수(누적,명)' , x = '연도')+
  ggtitle('제주청년 전입 그래프 ')





