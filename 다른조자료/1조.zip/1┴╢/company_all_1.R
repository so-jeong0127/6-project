setwd( "D:/proj")
ca <- read.csv( "제주산업조사.csv", header = T )
ca

library('ggplot2')


# 업종별 사업체수 및 종사자수 
#ggplot(data=ca, aes(x=reorder(ca$X, ca$사업체수), y=사업체수)) + geom_bar(stat='identity')
  
ggplot(data=ca, aes(x=reorder(ca$X, ca$사업체수), y=사업체수)) + geom_bar(stat='identity')+
  geom_bar( stat = "identity", width = 0.7 , fill = "steelblue")+
  labs(y = '사업체수(개)' , x = '지역')+
  ggtitle('제주도 업종별 사업체수')
  

  ggplot( df, aes( x = Area , y = Affirmation)) +
  geom_bar( stat = "identity", width = 0.7 , fill = "steelblue")+
  labs(y = '매우 그렇다 답변 비율(%)' , x = '지역')+
  ggtitle('창업 인식 개선도 조사 ')
